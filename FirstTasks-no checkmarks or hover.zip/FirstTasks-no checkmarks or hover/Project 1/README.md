# Review:

## Create a funtioncal to-do list using HTML/CSS

## Updates
- changed location of home button to left hand side
- made each individual tasks into bars on each of the to-do lists

## HTML
- Build a sample of a few items in a to-do list
- Add a form to add new items

## CSS
- Develop a responsive style for the list
- Create styles for hovering, clicking and completing tasks

## Javascript
- Store some sample tasks in an array using JSON
- Add new items to the list using the form
- Clicking an item indicates it as complete or incomplete

## Next Steps:

What other features could we use/create? Here are a few ideas:

- swipe to delete tasks
- be able to star important tasks and have tho appear in the important tasks list
- have all tasks go to all tasks list
- create a form for adding new tasks
- create a form for signing up
- 
